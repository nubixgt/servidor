import Navigation from '@/components/Navigation'
import HeroSection from '@/components/HeroSection'
import TecnologiaSection from '@/components/TecnologiaSection'
import NivelesSection from '@/components/ServicesSection'
import CarrerasSection from '@/components/CarrerasSection'
import ActividadesSection from '@/components/ActividadesSection'
import AboutSection from '@/components/AboutSection'
import GaleriaSection from '@/components/GaleriaSection'
import FacebookFeedSection from '@/components/FacebookFeedSection'
import ContactSection from '@/components/ContactSection'
import Footer from '@/components/Footer'
import WhatsAppButton from '@/components/WhatsAppButton'

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <HeroSection />
      <TecnologiaSection />
      <NivelesSection />
      <CarrerasSection />
      <ActividadesSection />
      <AboutSection />
      <GaleriaSection />
      <FacebookFeedSection />
      <ContactSection />
      <Footer />
      <WhatsAppButton />
    </div>
  )
}