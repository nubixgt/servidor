"use client";

import { Facebook, Instagram, Mail, Phone, MapPin } from 'lucide-react';
import Image from 'next/image';

export default function Footer() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-gradient-to-br from-gray-900 to-gray-800 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Logo & About */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="relative w-12 h-12">
                <Image
                  src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/LOGO-2020-1761860820111.png?width=100&height=100&resize=contain"
                  alt="Logo CYD"
                  fill
                  className="object-contain" />

              </div>
              <div>
                <div className="text-lg font-bold bg-gradient-to-r from-green-400 to-yellow-400 bg-clip-text text-transparent">
                  Colegio CYD
                </div>
                <div className="text-xs text-gray-400 !whitespace-pre-line">Ciencia y Desarrollo</div>
              </div>
            </div>
            <p className="text-sm text-gray-400 !whitespace-pre-line">Formando líderes con valores desde 1992. Educación de excelencia en Salama, Baja Verapaz.

            </p>
            <div className="flex space-x-3">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">

                <Facebook size={20} />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">

                <Instagram size={20} />
              </a>
            </div>
          </div>

          {/* Enlaces Rápidos */}
          <div>
            <h4 className="font-bold mb-4 text-lg">Enlaces Rápidos</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => scrollToSection('inicio')} className="text-gray-400 hover:text-white transition-colors">
                  Inicio
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('niveles')} className="text-gray-400 hover:text-white transition-colors">
                  Niveles Educativos
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('actividades')} className="text-gray-400 hover:text-white transition-colors">
                  Actividades
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('nosotros')} className="text-gray-400 hover:text-white transition-colors">
                  Sobre Nosotros
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('galeria')} className="text-gray-400 hover:text-white transition-colors">
                  Galería
                </button>
              </li>
              <li>
                <button onClick={() => scrollToSection('contacto')} className="text-gray-400 hover:text-white transition-colors">
                  Contacto
                </button>
              </li>
            </ul>
          </div>

          {/* Niveles */}
          <div>
            <h4 className="font-bold mb-4 text-lg">Niveles</h4>
            <ul className="space-y-2 text-sm text-gray-400">
              <li className="hover:text-white transition-colors cursor-pointer">Preprimaria</li>
              <li className="hover:text-white transition-colors cursor-pointer">Primaria</li>
              <li className="hover:text-white transition-colors cursor-pointer">Básicos</li>
              <li className="hover:text-white transition-colors cursor-pointer">Diversificado</li>
              <li className="hover:text-white transition-colors cursor-pointer">Bachillerato en Ciencias</li>
              <li className="hover:text-white transition-colors cursor-pointer">Perito Contador</li>
            </ul>
          </div>

          {/* Contacto */}
          <div>
            <h4 className="font-bold mb-4 text-lg">Contacto</h4>
            <ul className="space-y-3 text-sm text-gray-400">
              <li className="flex items-start space-x-3">
                <MapPin size={18} className="mt-0.5 flex-shrink-0" />
                <span>Salama, Baja Verapaz, Guatemala</span>
              </li>
              <li className="flex items-start space-x-3">
                <Phone size={18} className="mt-0.5 flex-shrink-0" />
                <div>
                  <div>+502 1234-5678</div>
                  <div>+502 9876-5432</div>
                </div>
              </li>
              <li className="flex items-start space-x-3">
                <Mail size={18} className="mt-0.5 flex-shrink-0" />
                <div>
                  <div>info@colegiocyd.edu.gt</div>
                  <div>inscripciones@colegiocyd.edu.gt</div>
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-sm text-gray-400 text-center md:text-left">
              © {new Date().getFullYear()} Colegio Particular Mixto CYD. Todos los derechos reservados.
            </p>
            <div className="flex space-x-6 text-sm text-gray-400">
              <a href="#" className="hover:text-white transition-colors">Privacidad</a>
              <a href="#" className="hover:text-white transition-colors">Términos</a>
            </div>
          </div>
        </div>
      </div>
    </footer>);

}