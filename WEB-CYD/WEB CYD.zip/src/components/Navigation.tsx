"use client";

import { useState, useEffect } from 'react';
import { Menu, X, GraduationCap, BookOpen, Users, Calendar, Image as ImageIcon, Phone, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Image from 'next/image';

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  const menuItems = [
  { id: 'inicio', label: 'Inicio', icon: GraduationCap },
  { id: 'tecnologia', label: 'Tecnología', icon: Zap },
  { id: 'niveles', label: 'Niveles', icon: BookOpen },
  { id: 'actividades', label: 'Actividades', icon: Users },
  { id: 'nosotros', label: 'Nosotros', icon: Users },
  { id: 'galeria', label: 'Galería', icon: ImageIcon },
  { id: 'contacto', label: 'Contacto', icon: Phone }];


  return (
    <nav className={`fixed w-full top-0 z-50 transition-all duration-300 ${
    isScrolled ? 'bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl shadow-lg' : 'bg-transparent'}`
    }>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => scrollToSection('inicio')}>
            <div className="relative w-14 h-14 sm:w-16 sm:h-16">
              <Image
                src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/LOGO-2020-1761860820111.png?width=200&height=200&resize=contain"
                alt="Colegio CYD"
                fill
                className="object-contain !w-full !h-full !max-w-full" />

            </div>
            <div className="hidden sm:block">
              <div className="text-xl font-bold bg-gradient-to-r from-green-600 to-yellow-500 bg-clip-text text-transparent !w-full !h-[26px]">
                Colegio CYD
              </div>
              <div className="text-xs text-muted-foreground !w-[99.8%] !h-8 !whitespace-pre-line">Ciencia y Desarrollo</div>
            </div>
          </div>
          
          {/* Desktop Menu */}
          <div className="hidden lg:flex items-center space-x-1">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className="flex items-center space-x-2 px-4 py-2 text-foreground/80 hover:text-foreground hover:bg-green-50 dark:hover:bg-green-950/30 rounded-lg transition-all font-medium group">

                  <Icon size={18} className="group-hover:scale-110 transition-transform" />
                  <span>{item.label}</span>
                </button>);

            })}
          </div>

          <div className="hidden lg:block">
            <Button
              onClick={() => scrollToSection('contacto')}
              className="bg-gradient-to-r from-green-600 to-yellow-500 hover:from-green-700 hover:to-yellow-600 text-white shadow-lg hover:shadow-xl transition-all">

              Inscripciones
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg hover:bg-muted transition-colors">

            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen &&
        <div className="lg:hidden py-4 space-y-2 border-t border-border/50 animate-fade-in">
            {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="flex items-center space-x-3 w-full px-4 py-3 text-foreground/80 hover:text-foreground hover:bg-green-50 dark:hover:bg-green-950/30 rounded-lg transition-all">

                  <Icon size={20} />
                  <span>{item.label}</span>
                </button>);

          })}
            <div className="px-4 pt-2">
              <Button
              onClick={() => scrollToSection('contacto')}
              className="w-full bg-gradient-to-r from-green-600 to-yellow-500">

                Inscripciones
              </Button>
            </div>
          </div>
        }
      </div>
    </nav>);

}