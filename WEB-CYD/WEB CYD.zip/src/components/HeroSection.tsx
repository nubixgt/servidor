"use client";

import { ArrowRight, BookOpen, Trophy, Users, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import { motion, useScroll, useTransform, useSpring } from 'framer-motion';
import { useRef } from 'react';

export default function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end start"]
  });

  // Smooth spring physics for animations
  const smoothProgress = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  // Background parallax
  const bgY = useTransform(smoothProgress, [0, 1], ["0%", "50%"]);
  const bgOpacity = useTransform(smoothProgress, [0, 0.5, 1], [1, 0.5, 0]);

  // Text animations - más dramáticos
  const textY = useTransform(smoothProgress, [0, 0.5, 1], ["0%", "-50%", "-150%"]);
  const textScale = useTransform(smoothProgress, [0, 0.3, 0.7, 1], [1, 1.05, 0.9, 0.7]);
  const textRotate = useTransform(smoothProgress, [0, 0.5, 1], [0, -3, -10]);
  const textBlur = useTransform(smoothProgress, [0, 0.6, 1], [0, 0, 10]);

  // Button animations
  const buttonY = useTransform(smoothProgress, [0, 0.4, 1], ["0%", "20%", "-100%"]);
  const buttonScale = useTransform(smoothProgress, [0, 0.3, 0.6], [1, 1.1, 0.8]);
  const buttonRotate = useTransform(smoothProgress, [0, 0.5, 1], [0, 5, 15]);

  // Stats animations
  const statsY = useTransform(smoothProgress, [0, 0.5, 1], ["0%", "100%", "200%"]);
  const statsOpacity = useTransform(smoothProgress, [0, 0.3, 0.6], [1, 1, 0]);

  // Jaguar image - solo una imagen
  const jaguarY = useTransform(smoothProgress, [0, 1], ["0%", "-80%"]);
  const jaguarX = useTransform(smoothProgress, [0, 1], ["0%", "10%"]);
  const jaguarScale = useTransform(smoothProgress, [0, 0.5, 1], [1, 1.2, 0.9]);
  const jaguarOpacity = useTransform(smoothProgress, [0, 0.4, 0.7, 1], [1, 1, 0.6, 0]);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section ref={sectionRef} id="inicio" className="relative min-h-[150vh] flex items-center justify-center overflow-hidden pt-20">
      {/* Animated Background */}
      <motion.div
        style={{ y: bgY, opacity: bgOpacity }}
        className="absolute inset-0 bg-gradient-to-br from-green-50 via-yellow-50 to-blue-50 dark:from-gray-900 dark:via-green-900/20 dark:to-yellow-900/20">

        <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
      </motion.div>

      {/* Animated Floating Elements with Enhanced Parallax */}
      <motion.div
        style={{ y: useTransform(smoothProgress, [0, 1], ["0%", "250%"]), scale: useTransform(smoothProgress, [0, 1], [1, 1.5]) }}
        className="absolute top-20 left-10 w-72 h-72 bg-green-500/20 rounded-full blur-3xl animate-pulse" />

      <motion.div
        style={{ y: useTransform(smoothProgress, [0, 1], ["0%", "-200%"]), scale: useTransform(smoothProgress, [0, 1], [1, 2]) }}
        className="absolute bottom-20 right-10 w-96 h-96 bg-yellow-500/20 rounded-full blur-3xl animate-pulse animation-delay-2000" />

      <motion.div
        style={{ scale: useTransform(smoothProgress, [0, 1], [1, 3]), opacity: useTransform(smoothProgress, [0, 0.5, 1], [0.3, 0.5, 0]) }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-500/10 rounded-full blur-3xl animate-pulse animation-delay-4000" />


      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 sm:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content with Enhanced Scroll Animations */}
          <motion.div
            style={{
              y: textY,
              scale: textScale,
              rotateZ: textRotate,
              filter: useTransform(textBlur, (val) => `blur(${val}px)`)
            }}
            className="space-y-8 text-center lg:text-left">

            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center space-x-2 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border border-green-200 dark:border-green-800 rounded-full px-4 py-2">

              <Sparkles className="w-4 h-4 text-yellow-500" />
              <span className="text-sm font-medium">Formando líderes desde 1992</span>
            </motion.div>

            {/* Main Heading with Perspective */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              style={{
                transformStyle: "preserve-3d",
                perspective: 1000
              }}
              className="text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight">

              <motion.span
                style={{
                  y: useTransform(smoothProgress, [0, 0.5], ["0%", "-30%"]),
                  scale: useTransform(smoothProgress, [0, 0.5], [1, 1.1])
                }}
                className="block mb-2">

                Educación de
              </motion.span>
              <motion.span
                style={{
                  y: useTransform(smoothProgress, [0, 0.5], ["0%", "-60%"]),
                  scale: useTransform(smoothProgress, [0, 0.5], [1, 1.2]),
                  rotateX: useTransform(smoothProgress, [0, 0.5], [0, 10])
                }}
                className="block bg-gradient-to-r from-green-600 via-yellow-500 to-blue-600 bg-clip-text text-transparent">

                Excelencia
              </motion.span>
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              style={{
                y: useTransform(smoothProgress, [0, 0.5], ["0%", "20%"]),
                opacity: useTransform(smoothProgress, [0, 0.4, 0.7], [1, 1, 0])
              }}
              className="text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto lg:mx-0">

              Colegio Particular Mixto con <span className="font-semibold text-green-600">instalaciones modernas e innovadoras</span>, dedicado a formar estudiantes con <span className="font-semibold text-yellow-600">ciencia y disciplina</span>.
            </motion.p>

            {/* Stats with Enhanced Animations */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              style={{ y: statsY, opacity: statsOpacity, scale: useTransform(smoothProgress, [0, 0.3, 0.6], [1, 1.05, 0.9]) }}
              className="grid grid-cols-2 sm:grid-cols-3 gap-6">

              <motion.div
                whileHover={{ scale: 1.08, y: -8 }}
                style={{
                  y: useTransform(smoothProgress, [0, 0.5], ["0%", "50%"]),
                  rotateY: useTransform(smoothProgress, [0, 0.5], [0, 15])
                }}
                className="group relative p-6 rounded-3xl bg-gradient-to-br from-green-500/10 via-emerald-500/10 to-teal-500/10 backdrop-blur-xl border-2 border-green-200/50 dark:border-green-700/50 cursor-pointer shadow-xl hover:shadow-2xl transition-all duration-500 overflow-hidden">
                
                {/* Animated gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-green-400/0 via-emerald-400/20 to-green-600/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                
                {/* Shine effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
                
                <div className="relative z-10">
                  <div className="text-4xl sm:text-5xl font-black bg-gradient-to-br from-green-600 via-emerald-600 to-teal-700 bg-clip-text text-transparent mb-2 group-hover:scale-110 transition-transform duration-300">+33</div>
                  <div className="text-sm font-semibold text-foreground/80 group-hover:text-foreground transition-colors">Años de Excelencia</div>
                  <div className="mt-3 h-1 w-12 rounded-full bg-gradient-to-r from-green-500 to-emerald-500 group-hover:w-full transition-all duration-500"></div>
                </div>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.08, y: -8 }}
                style={{
                  y: useTransform(smoothProgress, [0, 0.5], ["0%", "80%"]),
                  rotateY: useTransform(smoothProgress, [0, 0.5], [0, -15])
                }}
                className="group relative p-6 rounded-3xl bg-gradient-to-br from-yellow-500/20 via-orange-500/20 to-amber-500/20 backdrop-blur-xl border-4 border-yellow-400/70 dark:border-yellow-600/70 cursor-pointer shadow-2xl hover:shadow-3xl transition-all duration-500 overflow-hidden ring-4 ring-yellow-300/30 dark:ring-yellow-700/30">
                
                {/* Animated gradient overlay - más intenso */}
                <div className="absolute inset-0 bg-gradient-to-br from-yellow-400/30 via-orange-400/40 to-yellow-600/30 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                
                {/* Shine effect - más brillante */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
                
                {/* Pulso de fondo */}
                <div className="absolute inset-0 bg-yellow-500/10 animate-pulse"></div>
                
                {/* Estrellas decorativas */}
                <div className="absolute top-2 right-2 text-yellow-400 text-2xl">⭐</div>
                <div className="absolute bottom-2 left-2 text-orange-400 text-xl">✨</div>
                
                <div className="relative z-10">
                  <div className="text-2xl sm:text-3xl md:text-4xl font-black bg-gradient-to-br from-yellow-600 via-orange-600 to-amber-700 bg-clip-text text-transparent mb-2 group-hover:scale-110 transition-transform duration-300 whitespace-nowrap drop-shadow-lg !w-32 !h-[47px]">15,000+</div>
                  <div className="text-sm font-bold text-foreground group-hover:text-foreground transition-colors">Egresados Exitosos</div>
                  <div className="mt-3 h-1.5 w-12 rounded-full bg-gradient-to-r from-yellow-500 to-orange-500 group-hover:w-full transition-all duration-500 shadow-lg"></div>
                </div>
              </motion.div>

              <motion.div
                whileHover={{ scale: 1.08, y: -8 }}
                style={{
                  y: useTransform(smoothProgress, [0, 0.5], ["0%", "110%"]),
                  rotateY: useTransform(smoothProgress, [0, 0.5], [0, 20])
                }}
                onClick={() => scrollToSection('carreras')}
                className="group relative p-6 rounded-3xl bg-gradient-to-br from-blue-500/10 via-cyan-500/10 to-indigo-500/10 backdrop-blur-xl border-2 border-blue-200/50 dark:border-blue-700/50 cursor-pointer shadow-xl hover:shadow-2xl transition-all duration-500 overflow-hidden">
                
                <div className="absolute inset-0 bg-gradient-to-br from-blue-400/0 via-cyan-400/20 to-blue-600/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
                
                <div className="relative z-10">
                  <div className="text-4xl sm:text-5xl font-black bg-gradient-to-br from-blue-600 via-cyan-600 to-indigo-700 bg-clip-text text-transparent mb-2 group-hover:scale-110 transition-transform duration-300">19</div>
                  <div className="text-sm font-semibold text-foreground/80 group-hover:text-foreground transition-colors">Carreras Educativas</div>
                  <div className="mt-3 h-1 w-12 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 group-hover:w-full transition-all duration-500"></div>
                </div>
              </motion.div>
            </motion.div>

            {/* CTA Buttons with Dynamic Animations */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.8 }}
              style={{
                y: buttonY,
                scale: buttonScale,
                rotateZ: buttonRotate
              }}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">

              <motion.div whileHover={{ scale: 1.1, rotate: -2 }} whileTap={{ scale: 0.95 }}>
                <Button
                  onClick={() => scrollToSection('niveles')}
                  size="lg"
                  className="relative bg-gradient-to-r from-green-600 to-yellow-500 hover:from-green-700 hover:to-yellow-600 text-white px-8 py-6 text-lg rounded-full group shadow-xl hover:shadow-2xl transition-all overflow-hidden border-0">
                  
                  {/* Animated shine effect */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700"></div>
                  
                  <span className="relative z-10 flex items-center">
                    Conocer Niveles
                    <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
                  </span>
                </Button>
              </motion.div>

              <motion.div whileHover={{ scale: 1.1, rotate: 2 }} whileTap={{ scale: 0.95 }}>
                <Button
                  onClick={() => scrollToSection('contacto')}
                  size="lg"
                  className="relative group px-8 py-6 text-lg rounded-full backdrop-blur-xl bg-white/80 dark:bg-gray-800/80 border-2 border-green-500/50 hover:border-green-500 shadow-xl hover:shadow-2xl transition-all overflow-hidden">
                  
                  {/* Gradient overlay on hover */}
                  <div className="absolute inset-0 bg-gradient-to-r from-green-500/10 via-yellow-500/10 to-green-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  {/* Animated border glow */}
                  <div className="absolute inset-0 rounded-full bg-gradient-to-r from-green-500 via-yellow-500 to-green-500 opacity-0 group-hover:opacity-20 blur-xl transition-opacity duration-300"></div>
                  
                  <span className="relative z-10 flex items-center font-semibold bg-gradient-to-r from-green-600 to-yellow-600 bg-clip-text text-transparent">
                    <BookOpen className="mr-2" size={20} />
                    Inscripciones 2026
                  </span>
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Right Content - Una sola imagen del Jaguar */}
          <div className="relative min-h-[600px] lg:min-h-[700px]">
            {/* Jaguar - Tres Cuartos */}
            <motion.div
              style={{
                y: jaguarY,
                x: jaguarX,
                scale: jaguarScale,
                opacity: jaguarOpacity
              }}
              className="absolute inset-0 flex items-center justify-center">

              <div className="relative w-80 h-80 lg:w-[450px] lg:h-[450px]">
                <motion.div
                  animate={{
                    scale: [1, 1.2, 1],
                    opacity: [0.3, 0.5, 0.3]
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="absolute inset-0 bg-gradient-to-br from-green-400/30 via-yellow-400/30 to-blue-400/20 rounded-full blur-3xl" />

                <Image
                  src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/Jaguarcin-3-cuartos-1761938045002.png?width=8000&height=8000&resize=contain"
                  alt="Jaguar CYD"
                  fill
                  className="object-contain drop-shadow-2xl"
                  priority />

              </div>
            </motion.div>

            {/* Interactive Cards sin efectos de scroll */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1 }}
              className="absolute -bottom-8 left-0 right-0 grid grid-cols-2 gap-4 z-20">

              {/* Card 1 - Excelencia */}
              <motion.div
                whileHover={{ scale: 1.1, rotate: -5, y: -10 }}
                whileTap={{ scale: 0.95 }}
                className="group p-6 rounded-2xl bg-gradient-to-br from-green-500 to-emerald-600 text-white cursor-pointer shadow-xl hover:shadow-2xl transition-shadow">

                <Trophy className="w-10 h-10 mb-3 group-hover:rotate-12 group-hover:scale-110 transition-transform" />
                <h3 className="font-bold text-lg mb-1">Excelencia</h3>
                <p className="text-sm opacity-90">Académica y deportiva</p>
              </motion.div>

              {/* Card 2 - Educación */}
              <motion.div
                whileHover={{ scale: 1.1, rotate: 5, y: -10 }}
                whileTap={{ scale: 0.95 }}
                className="group p-6 rounded-2xl bg-gradient-to-br from-yellow-500 to-orange-500 text-white cursor-pointer shadow-xl hover:shadow-2xl transition-shadow">

                <BookOpen className="w-10 h-10 mb-3 group-hover:scale-125 transition-transform" />
                <h3 className="font-bold text-lg mb-1">Educación</h3>
                <p className="text-sm opacity-90">Integral y moderna</p>
              </motion.div>

              {/* Card 3 - Comunidad */}
              <motion.div
                whileHover={{ scale: 1.1, rotate: 5, y: -10 }}
                whileTap={{ scale: 0.95 }}
                className="group p-6 rounded-2xl bg-gradient-to-br from-blue-500 to-cyan-600 text-white cursor-pointer shadow-xl hover:shadow-2xl transition-shadow">

                <Users className="w-10 h-10 mb-3 group-hover:scale-125 transition-transform" />
                <h3 className="font-bold text-lg mb-1">Comunidad</h3>
                <p className="text-sm opacity-90">Valores y respeto</p>
              </motion.div>

              {/* Card 4 - Redes Sociales */}
              <motion.div
                whileHover={{ scale: 1.1, rotate: -5, y: -10 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => scrollToSection('facebook')}
                className="group p-6 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-600 text-white cursor-pointer shadow-xl hover:shadow-2xl transition-shadow flex flex-col items-center justify-center">

                <div className="relative w-16 h-16 mb-2">
                  <Image
                    src="https://slelguoygbfzlpylpxfs.supabase.co/storage/v1/render/image/public/document-uploads/LOGO-2020-1761860820111.png?width=200&height=200&resize=contain"
                    alt="Logo CYD"
                    fill
                    className="object-contain group-hover:rotate-6 group-hover:scale-110 transition-transform brightness-0 invert" />
                </div>
                <h3 className="font-bold text-lg mb-1">Redes Sociales</h3>
                <p className="text-sm opacity-90">Síguenos</p>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 1.5, repeat: Infinity }}
        style={{ opacity: useTransform(smoothProgress, [0, 0.3], [1, 0]) }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2">

        <div className="w-6 h-10 rounded-full border-2 border-green-600/40 flex items-start justify-center p-2">
          <motion.div
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            className="w-1 h-3 bg-green-600/60 rounded-full" />

        </div>
      </motion.div>
    </section>);

}