"use client"

import { Mail, Phone, MapPin, Clock, Send } from 'lucide-react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { useState } from 'react'

export default function ContactSection() {
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    telefono: '',
    mensaje: ''
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Aquí iría la lógica de envío del formulario
    console.log('Form submitted:', formData)
  }

  return (
    <section id="contacto" className="py-20 sm:py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-blue-50/30 to-background dark:via-blue-950/10"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl sm:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Contáctanos</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            ¿Listo para ser parte de nuestra familia educativa? Estamos aquí para ayudarte
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-bold mb-6">Información de Contacto</h3>
              <p className="text-muted-foreground mb-8">
                Visítanos o contáctanos para conocer más sobre nuestros programas educativos y proceso de inscripción.
              </p>
            </div>

            <div className="space-y-4">
              <Card className="p-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-2 border-border/50 hover:shadow-lg transition-all hover:-translate-y-1 group">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 p-3 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                    <MapPin className="w-full h-full text-white" />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Dirección</h4>
                    <p className="text-sm text-muted-foreground">
                      Salama, Baja Verapaz<br />
                      Guatemala
                    </p>
                  </div>
                </div>
              </Card>

              <Card className="p-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-2 border-border/50 hover:shadow-lg transition-all hover:-translate-y-1 group">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-600 p-3 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                    <Phone className="w-full h-full text-white" />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Teléfono</h4>
                    <p className="text-sm text-muted-foreground">
                      +502 1234-5678<br />
                      +502 9876-5432
                    </p>
                  </div>
                </div>
              </Card>

              <Card className="p-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-2 border-border/50 hover:shadow-lg transition-all hover:-translate-y-1 group">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-500 to-orange-600 p-3 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                    <Mail className="w-full h-full text-white" />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Email</h4>
                    <p className="text-sm text-muted-foreground">
                      info@colegiocyd.edu.gt<br />
                      inscripciones@colegiocyd.edu.gt
                    </p>
                  </div>
                </div>
              </Card>

              <Card className="p-6 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-2 border-border/50 hover:shadow-lg transition-all hover:-translate-y-1 group">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-pink-600 p-3 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg">
                    <Clock className="w-full h-full text-white" />
                  </div>
                  <div>
                    <h4 className="font-bold mb-1">Horario de Atención</h4>
                    <p className="text-sm text-muted-foreground">
                      Lunes a Viernes: 7:00 AM - 5:00 PM<br />
                      Sábados: 8:00 AM - 12:00 PM
                    </p>
                  </div>
                </div>
              </Card>
            </div>
          </div>

          {/* Contact Form */}
          <Card className="p-8 bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm border-2 border-border/50 shadow-xl">
            <h3 className="text-2xl font-bold mb-6">Solicita Información</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Nombre Completo *</label>
                <Input
                  type="text"
                  placeholder="Tu nombre"
                  value={formData.nombre}
                  onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                  required
                  className="bg-background/50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Email *</label>
                <Input
                  type="email"
                  placeholder="tu@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  className="bg-background/50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Teléfono *</label>
                <Input
                  type="tel"
                  placeholder="+502 1234-5678"
                  value={formData.telefono}
                  onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                  required
                  className="bg-background/50"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Mensaje</label>
                <Textarea
                  placeholder="Cuéntanos sobre tu interés en el colegio..."
                  value={formData.mensaje}
                  onChange={(e) => setFormData({ ...formData, mensaje: e.target.value })}
                  rows={4}
                  className="bg-background/50"
                />
              </div>
              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-green-600 to-yellow-500 hover:from-green-700 hover:to-yellow-600 text-white py-6 text-lg shadow-lg hover:shadow-xl transition-all group"
              >
                Enviar Mensaje
                <Send className="ml-2 group-hover:translate-x-1 transition-transform" size={20} />
              </Button>
            </form>
          </Card>
        </div>
      </div>
    </section>
  )
}